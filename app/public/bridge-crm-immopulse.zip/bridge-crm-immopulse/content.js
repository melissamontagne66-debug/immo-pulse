/**
 * content.js — Injecté sur les pages de l'intranet (formulaire « Créer un contact »)
 *
 * Reçoit les données d'un prospect depuis le Side Panel et pré-remplit
 * le formulaire SANS le valider.
 *
 * Spécificités de l'intranet détectées à l'inspection :
 *  - AngularJS 1.x (ng-model) → injection via setter natif + événement 'input'
 *  - ui-select (Civilité, Nationalité, Pays, Source) → simulation de clic
 *  - Téléphone → ui-mask "99 99 99 99 99" : on injecte le numéro formaté avec espaces
 *  - Adresse → autocomplétion Google Places : on pré-remplit le texte, le conseiller
 *    clique ensuite la suggestion pour déclencher on-place-changed (code postal/ville)
 *  - Sections en accordéon → dépliage automatique avant remplissage
 */

/* =====================================================================
 * ⚙️ ZONE DE CONFIGURATION — SÉLECTEURS DU FORMULAIRE
 * ===================================================================== */
const SELECTORS = {
  /* ----- Section IDENTITÉ (✅ confirmés) ----- */
  firstname:  '#firstNameControl',            // name="firstName"  ✅
  lastname:   '#lastNameControl',             // name="lastName"   ✅
  birthdate:  '#birthDateControl',            // name="birthDate"  ✅ (datepicker jj/mm/aaaa)
  job:        '#jobControl',                  // name="job"        ✅
  birthName:  '#birthNameControl',            // name="birthName"  ✅

  /* ----- Section COORDONNÉES / ADRESSE (✅ confirmés) -----
   * ⚠️ Les IDs sont DYNAMIQUES (phone2 → phone13, address1 → address15…) :
   *    on cible donc l'attribut name (stable) avec un préfixe. */
  phone:      'input[name^="phone"]',         // name="phone2"/"phone13"… ✅ (ui-mask)
  email:      'input[name^="emailPersonal-"]',// name="emailPersonal-3" ✅
  address1:   'input[name="address1"]',       // name stable, id dynamique ✅
  address2:   'input[name="address2"]',       // name="address2" ✅

  /* ----- Notes / Commentaires (✅ confirmé — onglet …/edit/comment) ----- */
  notes:      '#commentMessage'               // name="message" ✅
};

/** Libellés des ui-select (repérage par le texte du <label>). */
const UI_SELECT_FIELDS = {
  civility: 'Civilité'   // options : Monsieur / Madame / Mademoiselle
};

/** Civilité : 'icon' = icônes cliquables en haut du formulaire (par défaut),
 *  avec repli automatique sur le ui-select de la section IDENTITÉ. */
const CIVILITY_MODE = 'icon';

/** Sélecteurs des en-têtes d'accordéon repliés (Bootstrap / Angular). */
const ACCORDION_TOGGLES = [
  '.panel-heading.collapsed',
  'a.accordion-toggle.collapsed',
  '[data-toggle="collapse"].collapsed',
  '.panel-title a[aria-expanded="false"]'
];

/* ======================= OUTILS ======================= */

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Formate un numéro français pour le ui-mask « 99 99 99 99 99 ».
 * Accepte : 0612345678, 06 12 34 56 78, +33612345678, 0033612345678.
 */
function formatPhoneFR(raw) {
  let digits = String(raw || '').replace(/\D/g, '');
  if (digits.startsWith('0033')) digits = digits.slice(2);       // 0033… → 33…
  if (digits.startsWith('33') && digits.length === 11) {
    digits = '0' + digits.slice(2);                               // +33… → 0…
  }
  if (digits.length === 10) return digits.replace(/(\d{2})(?=\d)/g, '$1 ').trim();
  return raw; // autre format : injecté tel quel
}

/**
 * Renseigne un champ texte — compatible AngularJS (ng-model écoute 'input'),
 * React et Vue par sécurité.
 */
function fillField(selector, value) {
  if (value == null || value === '') return null; // rien à injecter
  const el = document.querySelector(selector);
  if (!el) return false;

  el.focus();
  const proto = el instanceof HTMLTextAreaElement
    ? HTMLTextAreaElement.prototype
    : HTMLInputElement.prototype;
  const nativeSetter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
  if (nativeSetter) nativeSetter.call(el, value);
  else el.value = value;

  el.dispatchEvent(new Event('input',  { bubbles: true })); // ng-model / React / Vue
  el.dispatchEvent(new Event('change', { bubbles: true })); // ng-change
  el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
  el.blur();
  return true;
}

/**
 * Sélectionne une option dans un ui-select AngularJS (repéré par son label).
 */
async function fillUiSelectByLabel(fieldLabel, optionText) {
  if (!optionText) return null;

  const labels = [...document.querySelectorAll('label, .control-label, legend')];
  const labelEl = labels.find((l) =>
    l.textContent.trim().toLowerCase().startsWith(fieldLabel.toLowerCase()));
  if (!labelEl) return false;

  const scope = labelEl.closest('.form-group, .field, .row, section, div');
  const container = scope?.querySelector('.ui-select-container');
  const toggle = container?.querySelector('.ui-select-toggle, .ui-select-match');
  if (!toggle) return false;

  toggle.click();
  await wait(150);
  const choices = [...document.querySelectorAll(
    '.ui-select-choices-row, .ui-select-choices-row-inner')];
  const wanted = optionText.trim().toLowerCase();
  const target = choices.find((c) => c.textContent.trim().toLowerCase() === wanted)
              || choices.find((c) => c.textContent.trim().toLowerCase().startsWith(wanted));
  if (!target) { document.body.click(); return false; } // referme si introuvable

  target.click();
  await wait(60);
  return true;
}

/** Correspondance civilité → classe de l'avatar Angular (repli sans libellé). */
const CIVILITY_AVATAR_CLASS = {
  'monsieur':        'avatar-male',
  'madame':          'avatar-female',
  'mademoiselle':    'avatar-female',
  'personne morale': 'avatar-organization'
};

/**
 * Clique sur l'icône de civilité (composant .myiad-avatar avec ng-click).
 * Stratégie 1 : repérer le libellé texte (« Madame ») affiché sous l'icône,
 *               puis cliquer l'avatar .myiad-avatar du même bloc.
 * Stratégie 2 : repli sur la classe d'avatar (avatar-male / avatar-female…).
 */
async function clickCivilityIcon(optionText) {
  if (!optionText) return null;
  const wanted = optionText.trim().toLowerCase();

  // Stratégie 1 — via le libellé texte affiché à côté / sous l'icône
  const label = [...document.querySelectorAll('label, span, p, figcaption, div')]
    .find((el) => el.children.length === 0
               && el.textContent.trim().toLowerCase() === wanted);
  if (label) {
    const block = label.parentElement;
    const avatar = block?.querySelector('.myiad-avatar')
                || block?.parentElement?.querySelector('.myiad-avatar')
                || block?.previousElementSibling?.querySelector?.('.myiad-avatar');
    if (avatar) {
      avatar.click();                       // déclenche ng-click="$ctrl.select(...)"
      await wait(80);
      return true;
    }
  }

  // Stratégie 2 — via la classe de l'avatar (sans libellé texte)
  const cls = CIVILITY_AVATAR_CLASS[wanted];
  if (cls) {
    const avatar = document.querySelector(`.iad-avatar.${cls}`)?.closest('.myiad-avatar');
    if (avatar) {
      avatar.click();
      await wait(80);
      return true;
    }
  }
  return false;
}

/**
 * Déplie toutes les sections d'accordéon repliées pour rendre
 * leurs champs accessibles dans le DOM, puis laisse AngularJS rendre.
 */
async function expandAllAccordions() {
  let clicked = 0;
  for (const sel of ACCORDION_TOGGLES) {
    for (const toggle of document.querySelectorAll(sel)) {
      toggle.click();
      clicked++;
    }
  }
  if (clicked > 0) {
    console.log(`[BridgeCRM] ${clicked} section(s) d'accordéon dépliée(s).`);
    await wait(400); // laisse le temps à AngularJS/Bootstrap de rendre les champs
  }
  return clicked;
}

/* ======================= REMPLISSAGE ======================= */

async function fillProspectForm(prospect) {
  const filled = [];
  const missing = [];
  const warnings = [];

  // Champs texte simples
  const mapping = {
    firstname: prospect.firstname,
    lastname:  prospect.lastname,
    birthdate: prospect.birthdate,             // format attendu : jj/mm/aaaa
    job:       prospect.job,
    birthName: prospect.birthName,
    phone:     formatPhoneFR(prospect.phone),  // ui-mask « 06 12 34 56 78 »
    email:     prospect.email,
    address1:  prospect.address,
    address2:  prospect.address2,
    notes:     prospect.notes
  };

  for (const [key, value] of Object.entries(mapping)) {
    const res = fillField(SELECTORS[key], value);
    if (res === true) filled.push(key);
    else if (res === false) missing.push(key);
  }

  // Cas particulier : le champ Notes vit sur l'onglet « …/edit/comment ».
  // Si on n'est pas sur cet onglet, on le signale proprement au conseiller.
  if (missing.includes('notes') && prospect.notes) {
    missing.splice(missing.indexOf('notes'), 1);
    warnings.push('Notes : ouvrez l’onglet "Notes" (en bas de votre page) puis recliquez « Remplir le formulaire ».');
  }

  // Civilité : icônes cliquables (mode par défaut), repli sur le ui-select
  if (prospect.civility) {
    let res = CIVILITY_MODE === 'icon'
      ? await clickCivilityIcon(prospect.civility)
      : false;
    if (res === false) {
      res = await fillUiSelectByLabel(UI_SELECT_FIELDS.civility, prospect.civility);
    }
    if (res === true) filled.push('civility');
    else if (res === false) missing.push('civility');
  }

  return { filled, missing, warnings };
}

/* ======================= RÉCEPTION DES MESSAGES ======================= */

// Garde anti double-enregistrement (injection de secours possible)
if (!window.__bridgeCrmListenerInstalled) {
  window.__bridgeCrmListenerInstalled = true;

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'IAD_FILL_PROSPECT') return; // pas notre message

    (async () => {
      await expandAllAccordions();           // 1. déplie les sections repliées
      return fillProspectForm(message.payload || {}); // 2. remplit
    })()
      .then(({ filled, missing, warnings }) => {
        console.log(`[BridgeCRM] Champs remplis : ${filled.join(', ') || 'aucun'}`,
                    missing.length ? `| introuvables : ${missing.join(', ')}` : '');
        sendResponse({ ok: filled.length > 0, filled, missing, warnings });
      })
      .catch((err) => {
        console.error('[BridgeCRM] Erreur de remplissage :', err);
        sendResponse({ ok: false, error: err.message });
      });
    return true; // réponse asynchrone : conserve le canal ouvert
  });

  console.log('[BridgeCRM] Content script prêt.');
}
