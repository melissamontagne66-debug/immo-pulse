/**
 * background.js — Service Worker (Manifest V3)
 * Bridge CRM by ImmoPulse
 * Rôle : ouvrir le Side Panel quand le conseiller clique sur l'icône de l'extension.
 */

// Ouvre le volet latéral au clic sur l'icône de l'extension
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error('[Bridge CRM] sidePanel error:', error));
