/**
 * sidepanel.js — Interface du conseiller (Side Panel)
 *
 * Deux modes au choix (persistants) :
 *  🌐 API ImmoPulse : connexion (mêmes identifiants que l'app) → GET /api/bridge/prospects
 *  📂 Fichier importé : import JSON/CSV local, AUCUNE connexion requise
 *
 * Au clic sur « Remplir le formulaire » : envoi des données au content.js
 * de l'onglet actif via chrome.tabs.sendMessage (avec injection de secours).
 */

/* ======================= CONFIGURATION ======================= */

/** URLs ImmoPulse (SANS slash final). */
const IMMOPULSE_APP_URL = 'https://immo-pulse.pages.dev';   // application (lien externe)
const IMMOPULSE_API_URL = 'https://immo-pulse-api.melissa-montagne66.workers.dev'; // API (Cloudflare Workers)

/** Chemins de l'API ImmoPulse. */
const API_PROSPECTS_PATH = '/api/bridge/prospects';  // GET prospects (cookie ou Bearer)
const API_LOGIN_PATH     = '/api/auth/login';        // POST {email, password} → cookie JWT HttpOnly

/** Délai (ms) entre l'injection de secours du content script et le renvoi du message. */
const RETRY_DELAY_MS = 150;

/* ======================= RÉFÉRENCES UI ======================= */

const listEl   = document.getElementById('prospect-list');
const tpl      = document.getElementById('tpl-card');
const statusEl = document.getElementById('status');
const connEl   = document.getElementById('conn-status');
const loginEl  = document.getElementById('conn-login');
const sinceEl  = document.getElementById('filter-since');
const loginPanelEl = document.getElementById('login-panel');
const fileBarEl    = document.getElementById('file-bar');

let MODE = 'api'; // 'api' | 'file' — restauré depuis chrome.storage au démarrage

function setStatus(msg, type = '') {
  statusEl.textContent = msg;
  statusEl.className = `status ${type}`;
}

async function setConnection(state) {
  // state: 'ok' | 'err' | 'offline' | 'test' | 'file' | 'loading'
  const labels = {
    ok:      '🟢 Connecté à ImmoPulse',
    err:     '🔴 Non connecté — identifiez-vous ci-dessous',
    offline: '🟠 ImmoPulse injoignable — réessayez dans un instant',
    test:    '🧪 Mode test (données locales)',
    file:    '📂 Mode fichier — aucune connexion requise',
    loading: '…'
  };
  connEl.textContent = labels[state] || labels.loading;
  connEl.className = `conn-badge conn-${state}`;

  // État connecté : bandeau vert bien visible + email du conseiller + déconnexion
  document.querySelector('.conn-bar').classList.toggle('connected', state === 'ok');
  document.getElementById('btn-logout').classList.toggle('hidden', state !== 'ok');
  if (state === 'ok') {
    const { immopulse_email } = await chrome.storage.local.get('immopulse_email');
    if (immopulse_email) connEl.textContent = `🟢 Connecté : ${immopulse_email}`;
  }

  // L'écran de connexion ne s'affiche QUE sur session expirée (401/403),
  // jamais sur une simple erreur réseau.
  const showLogin = state === 'err';
  loginEl.classList.toggle('hidden', !showLogin);
  loginPanelEl.classList.toggle('hidden', !showLogin);
}

/* ======================= DÉCONNEXION ======================= */

async function doLogout() {
  try {
    // Tente d'invalider la session côté API (suppression du cookie HttpOnly)
    await fetch(IMMOPULSE_API_URL + '/api/auth/logout', {
      method: 'POST',
      credentials: 'include'
    });
  } catch { /* endpoint absent ou injoignable : on nettoie localement quand même */ }

  await chrome.storage.local.remove(['immopulse_token', 'immopulse_email']);
  listEl.innerHTML = '<p class="empty-state">Connectez-vous ci-dessus pour charger vos prospects.</p>';
  await setConnection('err');
  setStatus('Déconnecté d’ImmoPulse.');
}

document.getElementById('btn-logout').addEventListener('click', doLogout);

/* ======================= SÉLECTEUR DE MODE ======================= */

async function setMode(mode, { reload = true } = {}) {
  MODE = mode;
  await chrome.storage.local.set({ bridge_mode: mode });

  document.getElementById('mode-api').classList.toggle('active', mode === 'api');
  document.getElementById('mode-file').classList.toggle('active', mode === 'file');
  fileBarEl.classList.toggle('hidden', mode !== 'file');

  if (reload) init();
}

document.getElementById('mode-api').addEventListener('click', () => setMode('api'));
document.getElementById('mode-file').addEventListener('click', () => setMode('file'));

/* ======================= CONNEXION API (POST /api/auth/login) ======================= */

async function doLogin() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const loginStatus = document.getElementById('login-status');
  const btn = document.getElementById('btn-login');

  if (!email || !password) {
    loginStatus.textContent = 'Email et mot de passe requis.';
    loginStatus.className = 'status err';
    return;
  }
  btn.disabled = true;
  loginStatus.textContent = 'Connexion…';
  loginStatus.className = 'status';

  try {
    const res = await fetch(IMMOPULSE_API_URL + API_LOGIN_PATH, {
      method: 'POST',
      credentials: 'include',               // reçoit le cookie JWT HttpOnly (SameSite=None; Secure)
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (res.status === 401 || res.status === 403) {
      loginStatus.textContent = 'Identifiants incorrects.';
      loginStatus.className = 'status err';
      return;
    }
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    // Si l'API renvoie aussi le JWT dans le corps, on le conserve
    // (secours Bearer si le cookie venait à être bloqué)
    try {
      const data = await res.json();
      const token = data?.token || data?.access_token || data?.jwt;
      if (token) await chrome.storage.local.set({ immopulse_token: token });
    } catch { /* pas de corps JSON : le cookie suffit */ }
    await chrome.storage.local.set({ immopulse_email: email });

    document.getElementById('login-password').value = '';
    await setConnection('ok');
    init();
  } catch (err) {
    console.error('[BridgeCRM] Login :', err);
    loginStatus.textContent = 'ImmoPulse injoignable — réessayez.';
    loginStatus.className = 'status err';
  } finally {
    btn.disabled = false;
  }
}

document.getElementById('btn-login').addEventListener('click', doLogin);
for (const id of ['login-email', 'login-password']) {
  document.getElementById(id).addEventListener('keydown', (e) => {
    if (e.key === 'Enter') doLogin();
  });
}

/* ======================= API IMMOPULSE ======================= */

/** Construit les options fetch : cookie de session + token Bearer éventuel. */
async function apiFetchOptions() {
  const opts = { credentials: 'include', headers: {} };
  const { immopulse_token } = await chrome.storage.local.get('immopulse_token');
  if (immopulse_token) opts.headers['Authorization'] = `Bearer ${immopulse_token}`;
  return opts;
}

/** Vérifie que le conseiller possède une session ImmoPulse active.
 *  Retourne true | 'not_logged' | 'offline'. */
async function checkConnection() {
  if (!IMMOPULSE_API_URL) { await setConnection('test'); return true; }
  await setConnection('loading');
  try {
    const res = await fetch(IMMOPULSE_API_URL + API_PROSPECTS_PATH, await apiFetchOptions());
    if (res.status === 401 || res.status === 403) { await setConnection('err'); return 'not_logged'; }
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    await setConnection('ok');
    return true;
  } catch (err) {
    // Erreur réseau ou 5xx : la session peut être valide — PAS d'écran de mot de passe
    console.warn('[BridgeCRM] API ImmoPulse injoignable :', err);
    await setConnection('offline');
    return 'offline';
  }
}

/** Charge TOUTES les pages de prospects (pagination par 100).
 *  Filtre « mis à jour depuis » (since=YYYY-MM-DD).
 *  Les tombstones { id, deleted: true } (sync incrémentale) sont ignorées. */
const PAGINATION_PARAM = 'offset'; // GET …/prospects?since=YYYY-MM-DD&offset=100
const PAGE_SIZE = 100;             // pages de 100 : offset 0, 100, 200…
const MAX_PAGES = 20;              // garde-fou

async function loadProspectsAPI(since) {
  const all = [];
  for (let page = 0; page < MAX_PAGES; page++) {
    const url = new URL(IMMOPULSE_API_URL + API_PROSPECTS_PATH);
    if (since) url.searchParams.set('since', since);
    url.searchParams.set(PAGINATION_PARAM, String(page * PAGE_SIZE));

    const res = await fetch(url, await apiFetchOptions());
    if (res.status === 401 || res.status === 403) {
      const e = new Error('NOT_LOGGED'); e.code = 'NOT_LOGGED'; throw e;
    }
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const arr = Array.isArray(data) ? data : data.prospects || [];

    all.push(...arr);
    if (arr.length < PAGE_SIZE) break; // dernière page atteinte
  }

  return all
    .filter((p) => p.deleted !== true)   // ignore les tombstones
    .map(normalizeProspect);             // variantes de noms de champs FR/EN
}

/* ======================= IMPORT DE FICHIER (JSON / CSV) ======================= */

/** Normalise les en-têtes/ clés (FR ou EN) vers le schéma interne. */
const KEY_ALIASES = {
  id:        ['id', 'ref', 'reference', 'référence'],
  civility:  ['civility', 'civilite', 'civilité'],
  firstname: ['firstname', 'prenom', 'prénom'],
  lastname:  ['lastname', 'nom'],
  birthdate: ['birthdate', 'naissance', 'date_naissance', 'date de naissance'],
  job:       ['job', 'profession'],
  phone:     ['phone', 'tel', 'telephone', 'téléphone', 'portable', 'mobile'],
  email:     ['email', 'mail', 'e-mail', 'courriel'],
  address:   ['address', 'adresse'],
  notes:     ['notes', 'note', 'commentaire', 'commentaires', 'message']
};

function normalizeProspect(raw, index) {
  const lower = {};
  for (const [k, v] of Object.entries(raw)) lower[k.toLowerCase().trim()] = v;
  const out = {};
  for (const [key, aliases] of Object.entries(KEY_ALIASES)) {
    for (const a of aliases) {
      if (lower[a] != null && lower[a] !== '') { out[key] = String(lower[a]).trim(); break; }
    }
  }
  if (!out.id) out.id = `IMP-${index + 1}`;
  return out;
}

/** Parseur CSV minimal (gère ; ou , et les valeurs entre guillemets). */
function parseCSV(text) {
  const lines = text.replace(/^\uFEFF/, '').trim().split(/\r?\n/);
  if (!lines.length) return [];
  const delim = lines[0].includes(';') ? ';' : ',';
  const splitLine = (line) => {
    const out = [];
    let cur = '', inQ = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        if (inQ && line[i + 1] === '"') { cur += '"'; i++; }
        else inQ = !inQ;
      } else if (c === delim && !inQ) { out.push(cur); cur = ''; }
      else cur += c;
    }
    out.push(cur);
    return out.map((s) => s.trim());
  };
  const headers = splitLine(lines[0]);
  return lines.slice(1).filter((l) => l.trim()).map((l) => {
    const cells = splitLine(l);
    const obj = {};
    headers.forEach((h, i) => { obj[h] = cells[i] ?? ''; });
    return obj;
  });
}

async function handleImportFile(file) {
  try {
    const text = await file.text();
    const raw = file.name.toLowerCase().endsWith('.csv')
      ? parseCSV(text)
      : JSON.parse(text);
    const arr = Array.isArray(raw) ? raw : raw.prospects || [];
    const prospects = arr.map(normalizeProspect).filter((p) => p.firstname || p.lastname);
    if (!prospects.length) throw new Error('Aucun contact valide trouvé.');
    await chrome.storage.local.set({ imported_prospects: prospects });
    renderProspects(prospects);
    setStatus(`📂 ${prospects.length} contact(s) importé(s) depuis « ${file.name} ».`, 'ok');
  } catch (err) {
    console.error('[BridgeCRM] Import :', err);
    setStatus('❌ Fichier illisible. Formats acceptés : .json (tableau) ou .csv (avec en-têtes).', 'err');
  }
}

document.getElementById('btn-import').addEventListener('click', () =>
  document.getElementById('file-input').click());
document.getElementById('file-input').addEventListener('change', (e) => {
  if (e.target.files[0]) handleImportFile(e.target.files[0]);
  e.target.value = '';
});

/* ======================= RENDU ======================= */

function renderProspects(prospects) {
  listEl.innerHTML = '';
  if (!prospects.length) {
    listEl.innerHTML = '<p class="empty-state">Aucun prospect à afficher.</p>';
    return;
  }
  for (const p of prospects) {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.card-name').textContent = `${p.firstname || ''} ${p.lastname || ''}`.trim();
    node.querySelector('.card-id').textContent = p.id || '';
    node.querySelector('.card-phone').textContent = `📞 ${p.phone || '—'}`;
    node.querySelector('.card-email').textContent = `✉️ ${p.email || '—'}`;
    node.querySelector('.card-notes').textContent = p.notes || '';
    node.querySelector('.btn-fill').addEventListener('click', (e) => fillInIAD(p, e.target));
    listEl.appendChild(node);
  }
}

/* ======================= ENVOI VERS L'ONGLET INTRANET ======================= */

async function fillInIAD(prospect, btn) {
  btn.disabled = true;
  setStatus('Envoi vers le formulaire…');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error('Aucun onglet actif trouvé.');

    const message = { type: 'IAD_FILL_PROSPECT', payload: prospect };

    let response;
    try {
      response = await chrome.tabs.sendMessage(tab.id, message);
    } catch {
      // Le content script n'est pas encore chargé sur cette page : injection de secours.
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      await new Promise((r) => setTimeout(r, RETRY_DELAY_MS));
      response = await chrome.tabs.sendMessage(tab.id, message);
    }

    if (response?.ok) {
      const missing = response.missing?.length
        ? ` (champs introuvables : ${response.missing.join(', ')})`
        : '';
      const warnings = response.warnings?.length ? ` ⚠️ ${response.warnings.join(' ')}` : '';
      setStatus(`✅ ${prospect.firstname} ${prospect.lastname} injecté${missing}.${warnings} Vérifiez puis Enregistrez.`, 'ok');
    } else {
      setStatus(`⚠️ ${response?.error || 'Réponse inattendue du content script.'}`, 'err');
    }
  } catch (err) {
    console.error('[BridgeCRM]', err);
    setStatus('❌ Échec : ouvrez d’abord la page « Créer un contact » de l’intranet dans l’onglet actif.', 'err');
  } finally {
    btn.disabled = false;
  }
}

/* ======================= INIT ======================= */

document.getElementById('btn-refresh').addEventListener('click', init);

async function init() {
  setStatus('Chargement…');

  /* ----- Mode FICHIER (aucune connexion requise) ----- */
  if (MODE === 'file') {
    setConnection('file');
    const { imported_prospects } = await chrome.storage.local.get('imported_prospects');
    if (imported_prospects?.length) {
      renderProspects(imported_prospects);
      setStatus(`📂 ${imported_prospects.length} contact(s) importé(s).`);
    } else {
      listEl.innerHTML = '<p class="empty-state">Importez un fichier JSON ou CSV pour afficher vos contacts.</p>';
      setStatus('Aucun fichier importé.');
    }
    return;
  }

  /* ----- Mode API IMMOPULSE ----- */
  try {
    const connected = await checkConnection();
    if (connected === 'not_logged') {
      listEl.innerHTML = '<p class="empty-state">Connectez-vous ci-dessus pour charger vos prospects.</p>';
      setStatus('Session ImmoPulse requise.', 'err');
      return;
    }
    if (connected === 'offline') {
      setStatus('API injoignable — cliquez sur « ↻ Charger les contacts » pour réessayer.', 'err');
      return;
    }
    const prospects = await loadProspectsAPI(sinceEl.value || '');
    renderProspects(prospects);
    const filtre = sinceEl.value ? ` (depuis le ${sinceEl.value})` : '';
    setStatus(`${prospects.length} prospect(s) chargé(s)${filtre}.`);
  } catch (err) {
    console.error('[BridgeCRM]', err);
    if (err.code === 'NOT_LOGGED') {
      await setConnection('err');
      listEl.innerHTML = '<p class="empty-state">Connectez-vous ci-dessus pour charger vos prospects.</p>';
      setStatus('Session ImmoPulse expirée.', 'err');
    } else {
      setStatus('Erreur de chargement des prospects.', 'err');
    }
  }
}

// Pré-remplit le lien externe vers l'application ImmoPulse
if (IMMOPULSE_APP_URL) loginEl.href = IMMOPULSE_APP_URL + '/login';

// Restaure le mode choisi puis démarre
(async () => {
  const { bridge_mode } = await chrome.storage.local.get('bridge_mode');
  await setMode(bridge_mode === 'file' ? 'file' : 'api');
})();
